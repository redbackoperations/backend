package com.example.androiddemo;

import android.content.Context;
import android.os.Message;
import android.widget.Toast;

import org.bouncycastle.jcajce.provider.digest.Keccak;
import org.bouncycastle.util.encoders.Hex;

import java.nio.charset.StandardCharsets;

public class Utils {

    public static String getResponseMessage(int code) {
        String message = "";
        switch (code) {
            case ResponseCode.SIGN_INUP_SUCCESS:
                message = "SIGN_IN_SUCCESS";
                break;
            case ResponseCode.SIGN_IN_FAILED:
                message = "SIGN_IN_FAILED";
                break;
            case ResponseCode.SIGN_UP_FAILED:
                message = "SIGN_UP_FAILED";
                break;
            case ResponseCode.EMPTY_RESPONSE:
                message = "EMPTY_RESPONSE";
                break;
            case ResponseCode.SERVER_ERROR:
                message = "SERVER_ERROR";
                break;
            case ResponseCode.JSON_SERIALIZATION:
                message = "JSON_SERIALIZATION";
                break;
            case ResponseCode.EXIT_SUCCESS:
                message = "EXIT_SUCCESS";
                break;
            case ResponseCode.REQUEST_FAILED:
                message = "REQUEST_FAILED";
                break;
            case ResponseCode.UNCHANGED_INFORMATION:
                message = "UNCHANGED_INFORMATIO";
                break;
        }
        return message;
    }

    public static void showMessage(Context context, Message message) {
        Toast.makeText(context, getResponseMessage(message.what), Toast.LENGTH_SHORT).show();
    }
}
