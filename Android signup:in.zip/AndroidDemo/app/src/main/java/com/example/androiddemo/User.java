package com.example.androiddemo;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
public class User {
    private int id;
    private String firstname;
    private String lastname;
    private String username;
    private String password;
    private String telephone;
    private String email;

    public User(String name, String password,String email,String firstname,String lastname,String telephone) {
        this.username = name;
        this.password = password;
        this.email= email;
        this.telephone=telephone;
        this.firstname=firstname;
        this.lastname=lastname;
    }
}
