package com.example.androiddemo;

public class ResponseCode {
    public static final int SIGN_INUP_SUCCESS = 200;


    public static final int SIGN_IN_FAILED = 3000;
    public static final int SIGN_UP_FAILED = 3001;


    public static final int EMPTY_RESPONSE = 4000;
    public static final int SERVER_ERROR = 4001;
    public static final int REQUEST_FAILED = 4002;
    public static final int JSON_SERIALIZATION = 4003;
    public static final int EXIT_SUCCESS = 4004;
    public static final int UNCHANGED_INFORMATION = 4005;
}
