package com.example.androiddemo;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import org.jetbrains.annotations.NotNull;

import java.io.IOException;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;
import okhttp3.ResponseBody;

public class MainActivity2 extends AppCompatActivity {
    private final OkHttpClient client = new OkHttpClient();
    private final ObjectMapper mapper = new ObjectMapper();
    private final Handler handler = new Handler(Looper.getMainLooper());
    private static final MediaType mediaType = MediaType.parse("application/json;charset=utf-8");
    private final Message message = new Message();
    EditText firstname;
    EditText lastname;
    EditText username;
    EditText password;
    EditText email;
    EditText telephone;
    EditText password2;
    Button Create;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        Create.setOnClickListener(new View.OnClickListener() {
                                      @Override
             public void onClick(View view) {
            String username1 = username.getText().toString();
            String password1 = password.getText().toString();
            String password3 = password2.getText().toString();
            String firstname1 = firstname.getText().toString();
            String email1 = password.getText().toString();
            String lastname1 = lastname.getText().toString();
            String telephone1 = password.getText().toString();
            Request request = null;
            try {
                if(username1!=null&&firstname1!=null&&password1==password3&password1!=null&&email1!=null&&telephone1!=null&&lastname1!=null)
                request = new Request.Builder()
                        .post(RequestBody.create(mapper.writeValueAsString(new User(username1, password1,firstname1,email1,lastname1,telephone1)), mediaType))
                        .url(NetworkSettings.SIGN_UP)
                        .build();
            } catch (JsonProcessingException e) {
                e.printStackTrace();
            }
            client.newCall(request).enqueue(new Callback() {
                @Override
                public void onFailure(@NotNull Call call, @NotNull IOException e) {
                    message.what = ResponseCode.REQUEST_FAILED;
                    handler.post(() -> Utils.showMessage(getApplicationContext(), message));
                    e.printStackTrace();
                }
                @Override
                public void onResponse(@NotNull Call call, @NotNull Response response) throws IOException {
                    if (response.isSuccessful()) {
                        ResponseBody body = response.body();
                        if (body != null) {
                            RestResponse restResponse = mapper.readValue(body.string(), RestResponse.class);
                            message.what = restResponse.getstatus();
                            if (message.what == ResponseCode.SIGN_INUP_SUCCESS) {
                                handler.post(() -> {
                                    Intent intent = new Intent(MainActivity2.this,MainActivity.class);
                                    startActivity(intent);
                                });
                            }
                        } else {
                            message.what = ResponseCode.EMPTY_RESPONSE;
                            Log.e("RESPONSE_BODY_EMPTY", response.message());
                        }
                    } else {
                        message.what = ResponseCode.SERVER_ERROR;
                        Log.e("SERVER_ERROR", response.message());
                    }
                    handler.post(() -> Utils.showMessage(getApplicationContext(), message));
                }
            });
        }
     });
    }

     public void findID(){
         firstname=findViewById(R.id.firstname);
         lastname=findViewById(R.id.lastname);
         username=findViewById(R.id.Username);
         password=findViewById(R.id.password);
         password2=findViewById(R.id.Password2);
         email=findViewById(R.id.email);
         telephone=findViewById(R.id.Phonenumber);
         Create=findViewById(R.id.Create);
     }
    }
