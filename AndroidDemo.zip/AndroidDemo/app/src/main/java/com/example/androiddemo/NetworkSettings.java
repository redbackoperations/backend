package com.example.androiddemo;

public class NetworkSettings {
    private static final String HOST = "10.0.2.2";
    private static final String PORT = "8080";
    public static final String SIGN_IN = "http://"+ HOST+":"+PORT +"/username";
    public static final String UPDATE = "http://"+ HOST +":"+PORT + "/update";
    public static final String DELETE = "http://"+ HOST +":"+PORT + "/delete";
}