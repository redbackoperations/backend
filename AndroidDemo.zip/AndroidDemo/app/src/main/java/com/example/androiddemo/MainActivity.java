package com.example.androiddemo;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.util.Log;
import android.view.View;
import android.widget.Toast;

import com.example.androiddemo.databinding.ActivityMainBinding;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import org.jetbrains.annotations.NotNull;

import java.io.IOException;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;
import okhttp3.ResponseBody;

public class MainActivity extends AppCompatActivity {

    private ActivityMainBinding binding;
    private final OkHttpClient client = new OkHttpClient();
    private final ObjectMapper mapper = new ObjectMapper();
    private int signInId = 0;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private static final MediaType mediaType = MediaType.parse("application/json;charset=utf-8");
    private final Message message = new Message();
    private String oldName;
    String token;
    String refreshtoken;
    private String oldPassword;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
    }

    public void signInUp(View view) {
        String name = binding.name.getText().toString();
        String password = binding.password.getText().toString();
        Request request = new Request.Builder()
                .get()
                .url(NetworkSettings.SIGN_IN + "?username=" + name + "&" + "password=" + password)
                .build();
        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(@NotNull Call call, @NotNull IOException e) {
                message.what = ResponseCode.REQUEST_FAILED;
                handler.post(() -> Utils.showMessage(getApplicationContext(), message));
                e.printStackTrace();
            }
            @Override
            public void onResponse(@NotNull Call call, @NotNull Response response) throws IOException {
                if (response.isSuccessful()) {
                    ResponseBody body = response.body();
                    if (body != null) {
                        RestResponse restResponse = mapper.readValue(body.string(), RestResponse.class);
                        message.what = restResponse.getstatus();
                        if (message.what == ResponseCode.SIGN_IN_SUCCESS) {
                            handler.post(() -> {
                                token=restResponse.gettoken();
                                refreshtoken=restResponse.getrefreshtoken();
                                Toast.makeText(MainActivity.this, token, Toast.LENGTH_LONG).show();
                                oldName = binding.name.getText().toString();
                                oldPassword = binding.password.getText().toString();
                            });
                        }
                    } else {
                        message.what = ResponseCode.EMPTY_RESPONSE;
                        Log.e("RESPONSE_BODY_EMPTY", response.message());
                    }
                } else {
                    message.what = ResponseCode.SERVER_ERROR;
                    Log.e("SERVER_ERROR", response.message());
                }
                handler.post(() -> Utils.showMessage(getApplicationContext(), message));
            }
        });
    }}


