package com.example.androiddemo;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@NoArgsConstructor
@Setter
@Getter
public class RestResponse {
    private int status;
    private String token;
    private String  msg;
    private String refreshtoken;

    public String gettoken() {
        return token;
    }

    public void settoken(String token) {
        this.token = token;
    }

    public String getrefreshtoken() {
        return refreshtoken;
    }

    public void setrefreshtoken(String refreshtoken) {
        this.refreshtoken = refreshtoken;
    }

    public int getstatus() {
        return status;
    }

    public void setstatus(int status) {
        this.status = status;
    }
}
